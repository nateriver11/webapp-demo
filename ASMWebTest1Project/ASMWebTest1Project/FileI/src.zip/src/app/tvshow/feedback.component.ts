import { Component } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';

interface FeedbackDetails {
  fullName: string | null;
  contact: string | null;
  email: string | null;
  content: string | null;
}

@Component({
  templateUrl: './feedback.component.html',
})
export class FeedbackComponent {
  details: FeedbackDetails = {
    fullName: null,
    contact: null,
    email: null,
    content: null,
  };

  onSubmit(myForm: NgForm) {
    console.log(myForm.value);
    console.log('Saved: ' + JSON.stringify(myForm.value));
    console.log(JSON.stringify(this.details));
  }

  isValidated(ctrl: NgModel): boolean | null {
    let result: boolean | null = ctrl.valid || ctrl.pristine || ctrl.untouched;
    return result;
  }

  getValidationClass(ctrl: NgModel): any {
    if (ctrl.touched && ctrl.value && this.isValidated(ctrl)) {
      return 'is-valid';
    } else if (!this.isValidated(ctrl)) {
      return 'is-invalid';
    } else {
      return '';
    }
  }
}
