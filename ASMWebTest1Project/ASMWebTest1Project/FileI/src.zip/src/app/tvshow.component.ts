import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './tvshow.component.html', //this is a html file
})
export class TvShowComponent {
  apiUrl: string = 'http://api.tvmaze.com/shows/';
  showId?: number; //nullable
  showName: string = '';
  showImg: string = '';
  cast: any;

  showRating?: number;

  constructor(private http: HttpClient, private router: Router) {}

  // theadBg: string = 'thead-dark';
  // onRatingMoused(message: string): void {
  //   switch (message) {
  //     case 'red':
  //       this.theadBg = 'bg-danger';
  //       break;
  //     case 'green':
  //       this.theadBg = 'bg-success';
  //       break;
  //     case 'orange':
  //       this.theadBg = 'bg-warning';
  //       break;
  //     default:
  //       this.theadBg = 'thead-dark';
  //       break;
  //   }
  // }

  loadShow(): void {
    if (this.showId) {
      this.http.get<any>(this.apiUrl + this.showId).subscribe((data: any) => {
        this.showName = data.name;
        this.showId = data.id;
        this.showImg = data.image.medium;
        // this.showRating = data.rating.average;
        // go to the welcome page
        this.router.navigate(['/welcome']);
      });

      this.http
        .get<any[]>(`http://api.tvmaze.com/shows/${this.showId}/cast`)
        .subscribe((data: any[]) => (this.cast = data));
    }
  }
}
