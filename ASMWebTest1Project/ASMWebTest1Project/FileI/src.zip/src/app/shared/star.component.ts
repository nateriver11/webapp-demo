import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'star-rating',
  templateUrl: './star.component.html',
})
export class StarComponent {
  @Input() rating: number = 6;

  ratingSequence(n: number): number[] {
    return Array.from(Array(n).keys());
  }

  @Output() ratingMoused: EventEmitter<string> = new EventEmitter<string>();

  onMouse(action: string) {
    if (action === 'over') {
      this.ratingMoused.emit(this.getStarColor());
    } else if (action === 'out') {
      this.ratingMoused.emit('');
    }
  }

  getStarClasses(i: number): string {
    // i is the index of stars
    if (i + 1 <= this.rating) {
      return 'fas fa-star'; // full star
    } else if (i < this.rating && this.rating < i + 1) {
      return 'fas fa-star-half-alt'; // half star
    } else {
      return 'far fa-star'; // blank star
    }
  }
  getStarColor(): string {
    if (this.rating <= 5) {
      return 'red';
    } else if (this.rating <= 8) {
      return 'orange';
    } else {
      return 'green';
    }
  }
}
