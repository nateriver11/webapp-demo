import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { TvShowComponent } from './tvshow.component';
import { StarComponent } from './shared/star.component';
import { RouterModule } from '@angular/router';
import { WelcomeComponent } from './tvshow/welcome.component';
import { CastComponent } from './tvshow/cast.component';
import { FeedbackComponent } from './tvshow/feedback.component';

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: 'cast/:showId', component: CastComponent },
      { path: 'welcome', component: WelcomeComponent },
      { path: 'feedback', component: FeedbackComponent },
      { path: '', redirectTo: 'welcome', pathMatch: 'full' },
    ]),
  ], //this module is to run in a browser
  declarations: [
    TvShowComponent,
    StarComponent,
    CastComponent,
    WelcomeComponent,
    FeedbackComponent,
  ],
  bootstrap: [TvShowComponent],
})
export class AppModule {}
